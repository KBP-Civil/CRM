<template>
  <svg width="16" height="16" fill="none" viewBox="0 0 16 16">
    <g class="es-line-reload" clip-path="url(#a)">
      <path
        fill="currentColor"
        fill-rule="evenodd"
        d="M9.743 2.189a6 6 0 0 0-6.558 2.596.5.5 0 0 0 .844.535 5 5 0 0 1 9.12 1.683l-1.187-.686a.5.5 0 0 0-.5.866l2.165 1.25a.5.5 0 0 0 .683-.183l1.25-2.165a.5.5 0 0 0-.866-.5l-.603 1.044a6 6 0 0 0-4.348-4.44ZM3.356 9.024l1.189.687a.5.5 0 0 0 .5-.866L2.88 7.595a.5.5 0 0 0-.683.183L.947 9.943a.5.5 0 1 0 .866.5l.603-1.044a6 6 0 0 0 10.9 1.816.5.5 0 0 0-.844-.536 5 5 0 0 1-9.116-1.655Z"
        class="Union"
        clip-rule="evenodd"
      />
    </g>
    <defs>
      <clipPath id="a" class="a">
        <path fill="currentColor" d="M.25 0h16v16h-16z" />
      </clipPath>
    </defs>
  </svg>
</template>
