<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M2.5 6.5V6.5C2.5 7.10397 2.86771 7.64708 3.42848 7.87139L9.25722 10.2029C9.73404 10.3936 10.266 10.3936 10.7428 10.2029L16.5715 7.87139C17.1323 7.64708 17.5 7.10397 17.5 6.5V6.5"
      stroke="currentColor"
    />
    <rect x="2.5" y="4" width="15" height="12" rx="2.5" stroke="currentColor" />
  </svg>
</template>
