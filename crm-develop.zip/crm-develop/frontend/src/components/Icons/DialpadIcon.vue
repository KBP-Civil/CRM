<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M8 4.00002C8.36819 4.00002 8.66667 3.70154 8.66667 3.33335C8.66667 2.96516 8.36819 2.66669 8 2.66669C7.63181 2.66669 7.33334 2.96516 7.33334 3.33335C7.33334 3.70154 7.63181 4.00002 8 4.00002Z"
      stroke="currentColor"
      stroke-width="1.33333"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M12.6667 4.00002C13.0349 4.00002 13.3333 3.70154 13.3333 3.33335C13.3333 2.96516 13.0349 2.66669 12.6667 2.66669C12.2985 2.66669 12 2.96516 12 3.33335C12 3.70154 12.2985 4.00002 12.6667 4.00002Z"
      stroke="currentColor"
      stroke-width="1.33333"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M3.33333 4.00002C3.70152 4.00002 4 3.70154 4 3.33335C4 2.96516 3.70152 2.66669 3.33333 2.66669C2.96514 2.66669 2.66666 2.96516 2.66666 3.33335C2.66666 3.70154 2.96514 4.00002 3.33333 4.00002Z"
      stroke="currentColor"
      stroke-width="1.33333"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M8 8.66665C8.36819 8.66665 8.66667 8.36817 8.66667 7.99998C8.66667 7.63179 8.36819 7.33331 8 7.33331C7.63181 7.33331 7.33334 7.63179 7.33334 7.99998C7.33334 8.36817 7.63181 8.66665 8 8.66665Z"
      stroke="currentColor"
      stroke-width="1.33333"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M12.6667 8.66665C13.0349 8.66665 13.3333 8.36817 13.3333 7.99998C13.3333 7.63179 13.0349 7.33331 12.6667 7.33331C12.2985 7.33331 12 7.63179 12 7.99998C12 8.36817 12.2985 8.66665 12.6667 8.66665Z"
      stroke="currentColor"
      stroke-width="1.33333"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M3.33333 8.66665C3.70152 8.66665 4 8.36817 4 7.99998C4 7.63179 3.70152 7.33331 3.33333 7.33331C2.96514 7.33331 2.66666 7.63179 2.66666 7.99998C2.66666 8.36817 2.96514 8.66665 3.33333 8.66665Z"
      stroke="currentColor"
      stroke-width="1.33333"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M8 13.3333C8.36819 13.3333 8.66667 13.0349 8.66667 12.6667C8.66667 12.2985 8.36819 12 8 12C7.63181 12 7.33334 12.2985 7.33334 12.6667C7.33334 13.0349 7.63181 13.3333 8 13.3333Z"
      stroke="currentColor"
      stroke-width="1.33333"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M12.6667 13.3333C13.0349 13.3333 13.3333 13.0349 13.3333 12.6667C13.3333 12.2985 13.0349 12 12.6667 12C12.2985 12 12 12.2985 12 12.6667C12 13.0349 12.2985 13.3333 12.6667 13.3333Z"
      stroke="currentColor"
      stroke-width="1.33333"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M3.33333 13.3333C3.70152 13.3333 4 13.0349 4 12.6667C4 12.2985 3.70152 12 3.33333 12C2.96514 12 2.66666 12.2985 2.66666 12.6667C2.66666 13.0349 2.96514 13.3333 3.33333 13.3333Z"
      stroke="currentColor"
      stroke-width="1.33333"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
