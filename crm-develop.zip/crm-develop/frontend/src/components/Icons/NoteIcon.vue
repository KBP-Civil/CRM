<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M10 4.5C10 3.39543 9.10457 2.5 8 2.5H5.75C4.64543 2.5 3.75 3.39543 3.75 4.5V15.5C3.75 16.6046 4.64543 17.5 5.75 17.5H14.25C15.3546 17.5 16.25 16.6021 16.25 15.4976C16.25 13.1374 16.25 12.6616 16.25 9.75319C16.25 9.2009 15.8023 8.75 15.25 8.75H11C10.4477 8.75 10 8.30228 10 7.75V5.3125V4.5Z"
      stroke="currentColor"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M7.5 2.5H9.4844C10.2191 2.5 10.9283 2.76964 11.4775 3.25777L15.2431 6.60497C15.8836 7.17427 16.25 7.99028 16.25 8.8472V10.625"
      stroke="currentColor"
    />
  </svg>
</template>
