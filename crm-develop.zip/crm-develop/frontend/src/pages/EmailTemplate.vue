<template>
  <div>
    <h1>Email Templates</h1>
    <p>Here is a list of email templates</p>
  </div>
</template>
