<template>
  <svg
    width="18"
    height="18"
    viewBox="0 0 18 18"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M9.02099 11.5599C10.662 11.5599 11.9923 10.2295 11.9923 8.58852C11.9923 6.9475 10.662 5.61719 9.02099 5.61719C7.37996 5.61719 6.04965 6.9475 6.04965 8.58852C6.04965 10.2295 7.37996 11.5599 9.02099 11.5599Z"
      stroke="currentColor"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M3.92462 15.2834C4.245 14.2791 4.85628 13.3883 5.68566 12.7269C6.63325 11.9711 7.80938 11.5596 9.02143 11.5596C10.2335 11.5596 11.4096 11.9711 12.3572 12.7269C13.1866 13.3883 13.7979 14.2791 14.1182 15.2834"
      stroke="currentColor"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <rect
      x="2.25"
      y="2.25"
      width="13.5"
      height="13.5"
      rx="2.5"
      stroke="currentColor"
    />
  </svg>
</template>
